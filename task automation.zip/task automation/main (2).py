import os
import shutil


source_folder = '/path/to/source_folder'
destination_folder = '/path/to/organized_folder'


file_types = {
    'Images': ['.jpg', '.jpeg', '.png', '.gif'],
    'Documents': ['.pdf', '.docx', '.txt', '.xls'],
    'Videos': ['.mp4', '.mkv', '.avi'],
    'Archives': ['.zip', '.rar', '.tar.gz'],
    'Audio': ['.mp3', '.wav']
}

def organize_files():
    
    for folder in file_types:
        folder_path = os.path.join(destination_folder, folder)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

  
    for filename in os.listdir(source_folder):
        file_path = os.path.join(source_folder, filename)
        
   
        if os.path.isdir(file_path):
            continue

        _, ext = os.path.splitext(filename)
        for folder, extensions in file_types.items():
            if ext.lower() in extensions:
                dest_folder = os.path.join(destination_folder, folder)
                shutil.move(file_path, os.path.join(dest_folder, filename))
                print(f'Moved: {filename} to {dest_folder}')
                break

if __name__ == '__main__':
    organize_files()
